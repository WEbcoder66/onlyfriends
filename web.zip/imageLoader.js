export default function imageLoader({ src }) {
  return src
}